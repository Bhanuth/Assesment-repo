# Yii2 Docker Swarm Deployment with CI/CD

## Objective

Deploy a PHP Yii2 application using Docker Swarm, reverse-proxied by NGINX running on the host. Automate with Ansible and CI/CD using GitHub Actions.

## Setup Instructions

1. Provision an EC2 instance (Ubuntu 22.04).
2. Allow ports: 22, 80, 443.
3. Clone this repository locally.
4. Update your `inventory` file with EC2 IP and SSH key.
5. Run Ansible playbooks:

```bash
ansible-playbook -i inventory ansible/install_docker.yml
ansible-playbook -i inventory ansible/install_nginx.yml
ansible-playbook -i inventory ansible/init_swarm.yml
```

6. Copy `docker-compose.yml` manually to `/home/ubuntu/` (or automate later).
7. Run:

```bash
ansible-playbook -i inventory ansible/deploy_app.yml
```

## GitHub Actions Setup

- Set the following secrets in your GitHub repository:
  - `DOCKERHUB_USERNAME`
  - `DOCKERHUB_PASSWORD`
  - `EC2_PUBLIC_IP`
  - `EC2_SSH_KEY`

On push to `main`, it will:
- Build Docker image
- Push to DockerHub
- SSH into EC2
- Update Docker Swarm service

## Assumptions
- Single-node Swarm.
- NGINX is only doing basic reverse proxy.
- Healthchecks added to container.

## Testing

After deployment, access your EC2 Public IP (`http://your-ec2-ip/`) and you should see the Yii2 app running.
